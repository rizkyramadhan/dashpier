self.__precacheManifest = [
  {
    "revision": "03b7f92cfc9e9f6198f6",
    "url": "/static/js/app.74b92983.chunk.js"
  },
  {
    "revision": "af3949ea885b2f025f6c",
    "url": "/static/js/npm.abortcontroller-polyfill.027b8c1b.chunk.js"
  },
  {
    "revision": "3cf5f8ae589adf4d83e1",
    "url": "/static/js/npm.babel.9dd16c87.chunk.js"
  },
  {
    "revision": "7e659fa82cb411b9c258",
    "url": "/static/js/npm.blueimp-md5.e512e27b.chunk.js"
  },
  {
    "revision": "e1826912ad6b2fc991e0",
    "url": "/static/js/npm.boolean.232c20e8.chunk.js"
  },
  {
    "revision": "e548a4b78daa540613f8",
    "url": "/static/js/npm.callstack.282bdf55.chunk.js"
  },
  {
    "revision": "0a3eca74cd373a37a31e",
    "url": "/static/js/npm.caseless.0d6292ab.chunk.js"
  },
  {
    "revision": "38b07769ae0b632d9d68",
    "url": "/static/js/npm.color-convert.95f94ab6.chunk.js"
  },
  {
    "revision": "8da07e3d0d9c1f1efaf0",
    "url": "/static/js/npm.color-name.a26cee97.chunk.js"
  },
  {
    "revision": "5536944986b95d8807e7",
    "url": "/static/js/npm.color-string.5e527d31.chunk.js"
  },
  {
    "revision": "0acebc586884f26ca46e",
    "url": "/static/js/npm.create-react-class.db28a616.chunk.js"
  },
  {
    "revision": "b87bf3c9360ac5f864de",
    "url": "/static/js/npm.create-react-context.9f06bffc.chunk.js"
  },
  {
    "revision": "30692946d95c47f4f289",
    "url": "/static/js/npm.cross-fetch.8b5115e2.chunk.js"
  },
  {
    "revision": "afcdda3c9c526ef96a14",
    "url": "/static/js/npm.css-in-js-utils.5d25dd98.chunk.js"
  },
  {
    "revision": "047dd6074e601fb2d214",
    "url": "/static/js/npm.d3-array.0f9bc907.chunk.js"
  },
  {
    "revision": "75debe36e863926053bd",
    "url": "/static/js/npm.d3-collection.d2903b0c.chunk.js"
  },
  {
    "revision": "2f131dd299d56cfc3429",
    "url": "/static/js/npm.d3-color.a71d6d68.chunk.js"
  },
  {
    "revision": "fe1b3665bd24a4410ad7",
    "url": "/static/js/npm.d3-ease.c9f84980.chunk.js"
  },
  {
    "revision": "e05162262d0032d12159",
    "url": "/static/js/npm.d3-format.1efe6fb0.chunk.js"
  },
  {
    "revision": "06193dea2855a4235a48",
    "url": "/static/js/npm.d3-interpolate.eeb3db17.chunk.js"
  },
  {
    "revision": "29fc2fc1dfb4dd57dc23",
    "url": "/static/js/npm.d3-path.4f0a47e8.chunk.js"
  },
  {
    "revision": "fa56fdb2c5ff81c38283",
    "url": "/static/js/npm.d3-scale.039c1cb2.chunk.js"
  },
  {
    "revision": "507053539d5be7949f2b",
    "url": "/static/js/npm.d3-shape.dc327d0d.chunk.js"
  },
  {
    "revision": "99b21213ebfa04659a85",
    "url": "/static/js/npm.d3-time.5b49ca67.chunk.js"
  },
  {
    "revision": "9d6c3dd46b3c0c04f9d0",
    "url": "/static/js/npm.d3-time-format.bb771ea5.chunk.js"
  },
  {
    "revision": "ff645549316df5c747bd",
    "url": "/static/js/npm.d3-timer.0cb6b5f8.chunk.js"
  },
  {
    "revision": "3a70ce9a594142e5e10a",
    "url": "/static/js/npm.debounce.77356f67.chunk.js"
  },
  {
    "revision": "d6b08bc432e2f2dabc45",
    "url": "/static/js/npm.decode-uri-component.5ef1a624.chunk.js"
  },
  {
    "revision": "ede05e060cd2caa02490",
    "url": "/static/js/npm.expo.ed9cbe32.chunk.js"
  },
  {
    "revision": "0adad6d607bcc21d6743",
    "url": "/static/js/npm.expo-asset.d09ee6fc.chunk.js"
  },
  {
    "revision": "4aa1827d7734be4a4c8a",
    "url": "/static/js/npm.expo-cli.bf8a36be.chunk.js"
  },
  {
    "revision": "fbef5017efe76f728a6c",
    "url": "/static/js/npm.expo-constants.58a0198e.chunk.js"
  },
  {
    "revision": "c861849dcb7ec9a69eaf",
    "url": "/static/js/npm.expo-file-system.38433322.chunk.js"
  },
  {
    "revision": "2b07f83419984b747919",
    "url": "/static/js/npm.expo-font.3b442504.chunk.js"
  },
  {
    "revision": "884a5203cca07b7d2d9d",
    "url": "/static/js/npm.fbjs.4cbc1395.chunk.js"
  },
  {
    "revision": "0e149825e7a255e41541",
    "url": "/static/js/npm.fontfaceobserver.70b2572c.chunk.js"
  },
  {
    "revision": "03db79ec3a63c23e71d7",
    "url": "/static/js/npm.frisbee.0b1cf3a5.chunk.js"
  },
  {
    "revision": "5c15e3eee920d4abfca6",
    "url": "/static/js/npm.gud.84f0d225.chunk.js"
  },
  {
    "revision": "c80a4dc6ab1c382e9a1e",
    "url": "/static/js/npm.hoist-non-react-statics.87ba848e.chunk.js"
  },
  {
    "revision": "21bbbe51c84b6a6f27ee",
    "url": "/static/js/npm.hyphenate-style-name.bf9c5495.chunk.js"
  },
  {
    "revision": "0d11fd995fe8eed251ae",
    "url": "/static/js/npm.inline-style-prefixer.cda857c2.chunk.js"
  },
  {
    "revision": "214d8ae1fb34a985d6d3",
    "url": "/static/js/npm.invariant.7b85f792.chunk.js"
  },
  {
    "revision": "0ad9ed22ad01d0935e43",
    "url": "/static/js/npm.is-arrayish.ae98cde8.chunk.js"
  },
  {
    "revision": "ea5ca723af9c9c095aee",
    "url": "/static/js/npm.lodash.11438dbf.chunk.js"
  },
  {
    "revision": "5699928384daba98ee30",
    "url": "/static/js/npm.mobx.ec995269.chunk.js"
  },
  {
    "revision": "79fb8b8967c26a8b304e",
    "url": "/static/js/npm.mobx-react-lite.1be26cf0.chunk.js"
  },
  {
    "revision": "e0fea7be66f8905b5747",
    "url": "/static/js/npm.ms.920417bc.chunk.js"
  },
  {
    "revision": "adf8a54dd1f10f465cef",
    "url": "/static/js/npm.normalize-css-color.5f547c96.chunk.js"
  },
  {
    "revision": "33e4f14c2cc79afa0e47",
    "url": "/static/js/npm.object-assign.4ee29b49.chunk.js"
  },
  {
    "revision": "cc1f5a4137ec2d102af4",
    "url": "/static/js/npm.path-browserify.e7fa34cf.chunk.js"
  },
  {
    "revision": "20b40321537a15ea9c98",
    "url": "/static/js/npm.prop-types.356501b9.chunk.js"
  },
  {
    "revision": "789a129428d9bbccef34",
    "url": "/static/js/npm.qs.9885e3dc.chunk.js"
  },
  {
    "revision": "107671c7bcb53dade889",
    "url": "/static/js/npm.query-string.66c39f25.chunk.js"
  },
  {
    "revision": "17f889a511a8fdfcea09",
    "url": "/static/js/npm.querystringify.5eed878f.chunk.js"
  },
  {
    "revision": "fc8ea68c04beda2d20a8",
    "url": "/static/js/npm.react.411c569a.chunk.js"
  },
  {
    "revision": "a036f109ec6f5304811b",
    "url": "/static/js/npm.react-dom.0a0aac96.chunk.js"
  },
  {
    "revision": "a2332b559180b643f576",
    "url": "/static/js/npm.react-fast-compare.4182e12f.chunk.js"
  },
  {
    "revision": "2388e021a618b9b8b457",
    "url": "/static/js/npm.react-is.da74d1d5.chunk.js"
  },
  {
    "revision": "ae35d58b0a196258f76a",
    "url": "/static/js/npm.react-lifecycles-compat.0270f8f9.chunk.js"
  },
  {
    "revision": "abb8e4dce39fab19e688",
    "url": "/static/js/npm.react-native-gesture-handler.4e814343.chunk.js"
  },
  {
    "revision": "2796f9f0723e2c375109",
    "url": "/static/js/npm.react-native-paper.6ee21f77.chunk.js"
  },
  {
    "revision": "dc9c76857834852d077f",
    "url": "/static/js/npm.react-native-screens.3b5012cd.chunk.js"
  },
  {
    "revision": "5678f5f04f844e042480",
    "url": "/static/js/npm.react-native-tab-view.069618ea.chunk.js"
  },
  {
    "revision": "819f8f8068a7972d34d0",
    "url": "/static/js/npm.react-native-web.3c2f42a9.chunk.js"
  },
  {
    "revision": "a55881a19e969dca05d9",
    "url": "/static/js/npm.react-navigation.8fe90e7f.chunk.js"
  },
  {
    "revision": "82bc84c14deff1c84ea1",
    "url": "/static/js/npm.react-navigation-drawer.4dc91633.chunk.js"
  },
  {
    "revision": "eb1cbdb5a6e321201349",
    "url": "/static/js/npm.react-navigation-stack.1d85739a.chunk.js"
  },
  {
    "revision": "d8a44009f5a26bd68a36",
    "url": "/static/js/npm.react-navigation-tabs.6445a41f.chunk.js"
  },
  {
    "revision": "24c14d715e32ec0a7b14",
    "url": "/static/js/npm.react-timer-mixin.00c0cb70.chunk.js"
  },
  {
    "revision": "1a949d4e57362106d1ce",
    "url": "/static/js/npm.requires-port.344a057b.chunk.js"
  },
  {
    "revision": "93ce800a72605c5180fb",
    "url": "/static/js/npm.simple-swizzle.3a51c1df.chunk.js"
  },
  {
    "revision": "c01f9040fac574455b5b",
    "url": "/static/js/npm.split-on-first.63d90945.chunk.js"
  },
  {
    "revision": "245661b1a8f058ad977e",
    "url": "/static/js/npm.strict-uri-encode.25fd268b.chunk.js"
  },
  {
    "revision": "c7cbf8b89a67e45d6732",
    "url": "/static/js/npm.ua-parser-js.98b5182a.chunk.js"
  },
  {
    "revision": "efa96a510e89b9e11486",
    "url": "/static/js/npm.unimodules.5ec6e12f.chunk.js"
  },
  {
    "revision": "5aa27699c8b7bacc2398",
    "url": "/static/js/npm.url-join.dabd2ced.chunk.js"
  },
  {
    "revision": "961005d36e6db54ce98c",
    "url": "/static/js/npm.url-parse.dc44cee8.chunk.js"
  },
  {
    "revision": "689694fce037167e1963",
    "url": "/static/js/npm.uuid.264146be.chunk.js"
  },
  {
    "revision": "a9101b2bec92f8ec7ab0",
    "url": "/static/js/npm.uuid-js.7c4b4191.chunk.js"
  },
  {
    "revision": "bc8d15f4979ae464cab3",
    "url": "/static/js/npm.victory-area.9dc34079.chunk.js"
  },
  {
    "revision": "00623226ae548210cf0c",
    "url": "/static/js/npm.victory-axis.10291866.chunk.js"
  },
  {
    "revision": "148ed2d50a6434a94877",
    "url": "/static/js/npm.victory-chart.4f85e4bf.chunk.js"
  },
  {
    "revision": "50ce4b685fc86fe07f39",
    "url": "/static/js/npm.victory-core.e45606e1.chunk.js"
  },
  {
    "revision": "a5d8ed920e9036c1848a",
    "url": "/static/js/npm.victory-group.7ddae7e5.chunk.js"
  },
  {
    "revision": "0adac16cf3116bbbf9d6",
    "url": "/static/js/npm.victory-pie.d733367c.chunk.js"
  },
  {
    "revision": "07bb339782acf2cb8a75",
    "url": "/static/js/npm.victory-polar-axis.8a279dd2.chunk.js"
  },
  {
    "revision": "b64e90e4a70d321a307b",
    "url": "/static/js/npm.victory-shared-events.12aff74f.chunk.js"
  },
  {
    "revision": "b81808c85aebaa2180ed",
    "url": "/static/js/runtime.032f37a6.js"
  },
  {
    "revision": "6165c9d7a2e729ba57b23dd93add5366",
    "url": "/static/media/back-icon-mask.6165c9d7.png"
  },
  {
    "revision": "744ce60078c17d86006dd0edabcd59a7",
    "url": "/./fonts/Entypo.ttf"
  },
  {
    "revision": "a37b0c01c0baf1888ca812cc0508f6e2",
    "url": "/./fonts/MaterialIcons.ttf"
  },
  {
    "revision": "b06871f281fee6b241d60582ae9369b9",
    "url": "/./fonts/FontAwesome.ttf"
  },
  {
    "revision": "3a2ba31570920eeb9b1d217cabe58315",
    "url": "/./fonts/AntDesign.ttf"
  },
  {
    "revision": "aa57854761a63cacadb9d3da18cd04a9",
    "url": "/static/media/bg2.aa578547.png"
  },
  {
    "revision": "bc9ef6e9a73caf2486a5bfe51a683fbc",
    "url": "/static/media/bg.bc9ef6e9.png"
  },
  {
    "revision": "f7fb34d1eab74a26abdb832e3db8dbde",
    "url": "/./fonts/Nunito-Light.ttf"
  },
  {
    "revision": "e9f64790b131c08d6b34a9ecdc453876",
    "url": "/./fonts/Nunito-Regular.ttf"
  },
  {
    "revision": "a8c930b08cd5fda37ea9f1c105d1ac61",
    "url": "/./fonts/Nunito-Bold.ttf"
  },
  {
    "revision": "900caa7db580afb9489434ed9ce5c978",
    "url": "/./fonts/Nunito-Black.ttf"
  },
  {
    "revision": "6beba7e6834963f7f171d3bdd075c915",
    "url": "/./fonts/Feather.ttf"
  },
  {
    "revision": "c6aef942e3668158ec29d4adcb2e768f",
    "url": "/./fonts/FontAwesome5_Brands.ttf"
  },
  {
    "revision": "872545dde71de3842234bf6afe80c4cb",
    "url": "/./fonts/FontAwesome5_Solid.ttf"
  },
  {
    "revision": "e20945d7c929279ef7a6f1db184a4470",
    "url": "/./fonts/Foundation.ttf"
  },
  {
    "revision": "b2e0fc821c6886fb3940f85a3320003e",
    "url": "/./fonts/Ionicons.ttf"
  },
  {
    "revision": "5a293a273bee8d740a045d9922b9a9ae",
    "url": "/./fonts/MaterialCommunityIcons.ttf"
  },
  {
    "revision": "d2285965fe34b05465047401b8595dd0",
    "url": "/./fonts/SimpleLineIcons.ttf"
  },
  {
    "revision": "d0c694b562b2208635f250762cd7fc79",
    "url": "/serve.json"
  },
  {
    "revision": "7a7bc7ead25db795e58b336f04d2624c",
    "url": "/favicon.ico"
  },
  {
    "revision": "75c5e16eb13c60c31e826d34a2f1d3bf",
    "url": "/manifest.json"
  },
  {
    "revision": "b337e000d32ba4ff41a3e3e14896a8c8",
    "url": "/index.html"
  }
];